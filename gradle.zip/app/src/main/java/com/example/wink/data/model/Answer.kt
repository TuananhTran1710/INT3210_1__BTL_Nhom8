package com.example.wink.data.model

data class Answer(
    val text: String
)